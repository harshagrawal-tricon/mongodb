package com.example.mongodemo.controller;

import java.util.Collection;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.mongodemo.model.Employee;
import com.example.mongodemo.service.EmployeeServiceImpl;

@RestController
@RequestMapping(value= "/emp", method=RequestMethod.GET)
public class EmployeeController {

	@Autowired
	EmployeeServiceImpl serv;

	//@PostMapping(value = "/create")
//	public String create(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("desgn") String desgn,@RequestParam("email") String email ) {
//		return serv.create(id, name, desgn, email);
//		
//	}
	
	@PostMapping(value = "/create")
	public String create(@RequestBody Employee emp ) {
		if(emp== null)
			return "NUll object is passed";
		else
			return serv.create(emp);
		
	}

	@GetMapping(value = "/getall")
	public Collection<Employee> getAll() {

		return serv.readAll();
	}

	@PutMapping(value = "/update/{employee-id}")
	public String update(@PathVariable(value = "employee-id") int id, @RequestBody Employee emp) {
		emp.setId(id); 
		serv.update(emp);
		return "Employee record for employee-id= " + id + " updated.";
	}

	@DeleteMapping(value = "/delete/{employee-id}")
	public String delete(@PathVariable(value = "employee-id") int id) {
		serv.deleteById(id);
		return "Employee record for employee-id= " + id + " deleted.";
	}

}
