package com.example.mongodemo.service;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mongodemo.dao.EmployeeDAO;
import com.example.mongodemo.model.Employee;

@Service
public class EmployeeServiceImpl {
	
	@Autowired
	EmployeeDAO empdao;
	
	
//	public String create(int id,String name,String desgn,String email)
//	{
//		Employee emp=new Employee(id,name,desgn,email);
//		empdao.save(emp);
//		return "employee created with id = " + id;
//	}
	
	public String create(Employee emp)
	{
		empdao.save(emp);
		return "employee created with id = " + emp.getId();
	}
	
//	
	public Collection<Employee> readAll()
	{
		return empdao.findAll();
	}

	public void deleteById(int id)
	{
		empdao.deleteById(id);
	}
	
	public void update(Employee emp)
	{
		empdao.save(emp);
	}
}
